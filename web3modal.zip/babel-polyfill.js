require('@babel/register')({
  extensions: ['.ts', '.js', '.tsx', '.jsx']
})
