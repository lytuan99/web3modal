# Binance Chain Wallet

1. Set Provider Options

```typescript
const providerOptions = {
  binancechainwallet: {
    package: true
  }
};
```