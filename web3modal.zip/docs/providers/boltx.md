# Bolt-X Wallet

1. Set Provider Options

```typescript
const providerOptions = {
  boltx: {
    package: true
  }
};
```