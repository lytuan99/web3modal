declare module "@walletconnect/web3-provider";
declare module "*.svg" {
  export default "" as string;
}
declare module "*.png" {
  export default "" as string;
}
declare module "*.jpg" {
  export default "" as string;
}
declare module "*.jpeg" {
  export default "" as string;
}
declare module "*.gif" {
  export default "" as string;
}
declare module "*.bmp" {
  export default "" as string;
}
declare module "*.tiff" {
  export default "" as string;
}
