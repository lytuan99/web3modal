export const CONNECT_EVENT = "connect";
export const ERROR_EVENT = "error";
export const CLOSE_EVENT = "close";
export const SELECT_EVENT = "select";
