/* global describe it  */

describe("// ------------ web3modal ----------- //", () => {
  it("needs tests", () => {});
});
